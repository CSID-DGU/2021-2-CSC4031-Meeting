   const scriptstr = "Transcript: 십강이 내가 십강 근현대사 십강 끝자락이 되겠고요 칠판 조만간에 더 큰 칠판으로 저희가 또 더 좋은 조명과 더 Transcript: 비므로 뵙지 않을까 싶어요 계속 연구하고 있습니다 자유 부분은요 볼까요 뭐라고 하나 제가 말씀드렸던 단접성 도로 초대 Transcript: 이승만 대통령 선출 되고요 우리 신민회의 멤버였던 신흥무관학교를 세우셨던 Transcript: 동생이 신 이시영 선생의 국무총리에 올라서게 됩니다 틀렸습니다 죄송합니다 Transcript: 선생님 주차 초대 대통령은 이승만 이고요 이승만 대통령 그리고"
   const arr = scriptstr.split("Transcript: "); //. 을 기준으로 한문장씩 갈림
   //줄바꾸기기준으로 하려면 "\n "입력하면 됨
   let tagArea = document.getElementById('script'); //p태그 생성될 div


   //자막 받아와서 출력

window.onload = function(){
	
	  document.getElementById("start").onclick=realtimescript;
	  
      function realtimescript(){
         console.log(1);
         intervalid();
         setTimeout(() => {
            clearInterval(intervalid());      
         }, 52501);
         
      }

      i=1;
      function intervalid(){
          setInterval(() => {
            console.log(2);
            textout(i,arr[i]);
            i=i+1;         
         }, 10500);
      }
      
      function textout(l,arr){
         console.log(3);
         let new_pTag = document.createElement('p'); //p태그 생성
         new_pTag.setAttribute('id', 'changecolor'); 
         new_pTag.innerHTML = arr; //p태그 내용입력
         tagArea.appendChild(new_pTag);
      }

}



//다음페이지로 넘어가기
	window.addEventListener('click', function() {
		
		
		document.getElementById("nextpage").onclick=nextPage;
		function nextPage()  {
		var link='./savepage.html';
		window.open(link);
		}
		
		
	});