        $("#btnPrintleft").live("click", function () {
            var divContents = $("#lecturescript").html();
            var printWindow = window.open('', '', 'height=500,width=800');
            printWindow.document.write('<html><head><title>DIV Contents</title>');
            printWindow.document.write('</head><body >');
            printWindow.document.write(divContents);
            printWindow.document.write('</body></html>');
            printWindow.document.close();
            printWindow.print();
        });


        $("#btnPrintright").live("click", function () {
            var divContents = $("#lecturesummary").html();
            var printWindow = window.open('', '', 'height=500,width=800');
            printWindow.document.write('<html><head><title>DIV Contents</title>');
            printWindow.document.write('</head><body >');
            printWindow.document.write(divContents);
            printWindow.document.write('</body></html>');
            printWindow.document.close();
            printWindow.print();
        });
		
		
//요약 불러오기 버튼 누르면 실행되는 함수
$("#btnsum").on("click", function(){
	//var sumdata = $(".lecturesum").html(); //요약들어갈 div

		//요청보내기
			const config = {
			method: "get"
			};
		
			fetch('http://localhost:8000/summary', config)
				.then(response => response.json())
				.then(data => {
				//.then(data => console.log(data))로 JSON형태로 변환된 내용확인가능 확인 후 다시 주석처리하면 됨
				//const id = document.createElement("div"); 
				const summarytext = document.createElement("div"); 
				
				summarytext.textContent = data.summarytext; //data. JSON형태에서의 요약데이터가 들어가는 key값(몰라서 summarytext로 넣어둠)
				
				const sumInfo = document.getElementById("lecturesum");
				sumInfo.appendChild(summarytext);
				
				})
				.catch(error => console.log(error));

		});
		

		
		