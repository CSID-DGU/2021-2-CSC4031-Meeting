	const scriptstr = "실시간스크립트 입니다. 시험에 나옵니다. 중요합니다. 어쩌고 저쩌고. 다음문장. 또다른문장. 중얼중얼."//받아올 내용 담길곳
	const arr = scriptstr.split(". "); //. 을 기준으로 한문장씩 갈림
	//줄바꾸기기준으로 하려면 "\n "입력하면 됨
	let tagArea = document.getElementById('script'); //p태그 생성될 div


window.onload = function(){

	//자막 받아와서 출력


	document.getElementById("start").onclick=realtimescript;

		function realtimescript(){
			for(var l = 0; l<arr.length; l++){
				let new_pTag = document.createElement('p'); //p태그 생성
				new_pTag.setAttribute('id', 'changecolor'); 
				new_pTag.innerHTML = arr[l]; //p태그 내용입력
				
				tagArea.appendChild(new_pTag);
			}

		}



}

	window.addEventListener('click', function(){


	var keywords=new Array(); //키워드 저장할 배열
	var str = document.getElementById("script").innerText;
	//var strcol = document.getElementById("changecolor");
	const btn = document.getElementById("send");

	function saveKeyword(){
		
		
		//설정한 키워드 출력
		
		var keyword = document.getElementById("keyword").value;
		keywords.push(keyword); 

		
		//console.log('설정한키워드: ${keyword.value}');
		
		for(var a = 0; a <keywords.length; a++){
			document.getElementById('setkeyword').innerHTML=keywords;

		}

		
		for(var b = 0; b <keywords.length; b++){
			
			let fromIndex = arr.indexOf(keywords[b]);
			while(fromIndex != -1) { //실시간스크립트 들어가는 div에 해당단어가 있는동안
				arr[fromIndex].style.color = "red"; //키워드가 들어간 문장색을 red로 바꿈
				fromIndex = arr.indexOf(keywords[b], fromIndex+1);
				
				console.log('색바뀜완료 ㅋ'); //잘 작동하나 테스트한다고 넣음
			}
		}

//		const keywordsString= JSON.stringify(keywords);
//		console.log(keywordsString);
		
//		localStorage.setItem("keyword", keywordsString);
//		console.log(localStorage.getItem("keyword"));
		
//		const result = localStorage.getItem("keyword");
//		console.log(JSON.parse(result));
		
		console.log('키워드저장됨ㅋ');
	}

		btn.onclick=saveKeyword;
	

	});





//다음페이지로 넘어가기
	window.addEventListener('click', function() {
		
		
		document.getElementById("nextpage").onclick=nextPage;
		function nextPage()  {
		var link='./savepage.html'
		window.open(link);
		}
		
		
	});



//키워드설정버튼
	var acc = document.getElementsByClassName("accordion");
	var i;

	for (i = 0; i < acc.length; i++) {
		acc[i].onclick = function(){
			this.classList.toggle("active");
			this.nextElementSibling.classList.toggle("show");
	  }
	}
	
