window.onload = function(){

	var keywords=new Array(); //키워드 저장할 배열
	var str = document.getElementById("script").innerText;
	var strcol = document.getElementById("changecolor");
	const btn = document.getElementById("send");

	function saveKeyword(){
		
		
		//설정한 키워드 출력
		
		var keyword = document.getElementById("keyword").value;
		keywords.push(keyword); 

		
		console.log('설정한키워드: ${keyword.value}');
		
		for(var a = 0; a <keywords.length; a++){
			document.getElementById('setkeyword').innerHTML=keywords;

		}

		
		for(var b = 0; b <keywords.length; b++){
			if (str.indexOf(keywords[b]) != -1) { //실시간스크립트 들어갈 div읽어오기
				console.log('색바뀜완료 ㅋ'); //잘 작동하나 테스트한다고 넣음
				strcol.style.color = "red"; //키워드 or 키워드가 들어간 문장만 색을 바꾸고 싶은데 방법을 몰갯슴 ~


			}
		}

//		const keywordsString= JSON.stringify(keywords);
//		console.log(keywordsString);
		
//		localStorage.setItem("keyword", keywordsString);
//		console.log(localStorage.getItem("keyword"));
		
//		const result = localStorage.getItem("keyword");
//		console.log(JSON.parse(result));

	}

		btn.onclick=saveKeyword;
		console.log('키워드저장됨ㅋ');
	
}



//다음페이지로 넘어가기
	window.addEventListener('click', function() {
		
		
		document.getElementById("nextpage").onclick=nextPage;
		function nextPage()  {
		var link='./savepage.html'
		window.open(link);
		}
		
		
	});



//키워드설정버튼
	var acc = document.getElementsByClassName("accordion");
	var i;

	for (i = 0; i < acc.length; i++) {
		acc[i].onclick = function(){
			this.classList.toggle("active");
			this.nextElementSibling.classList.toggle("show");
	  }
	}
	
